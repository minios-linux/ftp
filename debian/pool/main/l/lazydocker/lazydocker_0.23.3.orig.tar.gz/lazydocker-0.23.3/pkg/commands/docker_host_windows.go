package commands

const (
	defaultDockerHost = "npipe:////./pipe/docker_engine"
)
