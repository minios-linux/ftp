package commands

type Project struct {
	Name string
}
