package gui

import "github.com/jesseduffield/lazydocker/pkg/gui/panels"

func (gui *Gui) intoInterface() panels.IGui {
	return gui
}
