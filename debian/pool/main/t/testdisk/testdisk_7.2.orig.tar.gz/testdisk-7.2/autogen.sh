#!/bin/sh
mkdir config
autoreconf --install -W all -I config
