The DOS version of TestDisk & PhotoRec should work under
- MSDOS 6.x
- FreeDOS
- Windows 95
- Windows 98

If you are using NT 4, Windows 2000..., run the Windows version of TestDisk.
You can download it from https://www.cgsecurity.org/wiki/TestDisk_Download

TestDisk & PhotoRec documentation can be found online:
- https://www.cgsecurity.org/wiki/TestDisk
- https://www.cgsecurity.org/wiki/PhotoRec
