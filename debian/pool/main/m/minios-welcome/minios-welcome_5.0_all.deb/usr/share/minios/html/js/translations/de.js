window.translations = {
    "MiniOS - Fast. Simple. Reliable.": "MiniOS - Schnell. Einfach. Zuverlässig.",
    "Website": " Webseite",
    "News": " Nachrichten",
    "Community": " Gemeinschaft",
    "Documentation": " Dokumentation",
    "Source code": " Quellcode",
    "Thank you for choosing MiniOS.": "Danke, dass Sie sich für MiniOS entschieden haben.",
    "We hope you enjoy our system. We try to make MiniOS beautiful, simple and convenient for you.": "Wir hoffen, dass Ihnen unser System gefällt. Wir versuchen, MiniOS schön, einfach und bequem für Sie zu gestalten."
};