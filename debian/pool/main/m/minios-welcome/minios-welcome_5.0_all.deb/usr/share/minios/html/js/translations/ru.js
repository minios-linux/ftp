window.translations = {
    "MiniOS - Fast. Simple. Reliable.": "MiniOS - Быстро. Просто. Надежно.",
    "Website": " Веб-сайт",
    "News": " Новости",
    "Community": " Сообщество",
    "Documentation": " Документация",
    "Source code": " Исходный код",
    "Thank you for choosing MiniOS.": "Спасибо за выбор MiniOS.",
    "We hope you enjoy our system. We try to make MiniOS beautiful, simple and convenient for you.": "Мы надеемся, что наша система вам понравится. Мы стараемся сделать MiniOS красивой, простой и удобной для вас."
};