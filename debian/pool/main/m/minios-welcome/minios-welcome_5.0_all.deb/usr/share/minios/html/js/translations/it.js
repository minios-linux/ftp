window.translations = {
    "MiniOS - Fast. Simple. Reliable.": "MiniOS - Veloce. Semplice. Affidabile.",
    "Website": " Sito web",
    "News": " Notizie",
    "Community": " Comunità",
    "Documentation": " Documentazione",
    "Source code": " Codice sorgente",
    "Thank you for choosing MiniOS.": "Grazie per aver scelto MiniOS.",
    "We hope you enjoy our system. We try to make MiniOS beautiful, simple and convenient for you.": "Speriamo che il nostro sistema ti piaccia. Cerchiamo di rendere MiniOS bello, semplice e conveniente per te."
};