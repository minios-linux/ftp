window.translations = {
    "MiniOS - Fast. Simple. Reliable.": "MiniOS - Rápido. Simple. Confiable.",
    "Website": " Sitio web",
    "News": " Noticias",
    "Community": " Comunidad",
    "Documentation": " Documentación",
    "Source code": " Código fuente",
    "Thank you for choosing MiniOS.": "Gracias por elegir MiniOS.",
    "We hope you enjoy our system. We try to make MiniOS beautiful, simple and convenient for you.": "Esperamos que disfrute de nuestro sistema. Intentamos hacer MiniOS hermoso, simple y conveniente para usted."
};