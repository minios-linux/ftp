window.translations = {
    "MiniOS - Fast. Simple. Reliable.": "MiniOS - Rapide. Simple. Fiable.",
    "Website": " Site web",
    "News": " Nouvelles",
    "Community": " Communauté",
    "Documentation": " Documentation",
    "Source code": " Code source",
    "Thank you for choosing MiniOS.": "Merci d'avoir choisi MiniOS.",
    "We hope you enjoy our system. We try to make MiniOS beautiful, simple and convenient for you.": "Nous espérons que vous apprécierez notre système. Nous essayons de rendre MiniOS beau, simple et pratique pour vous."
};