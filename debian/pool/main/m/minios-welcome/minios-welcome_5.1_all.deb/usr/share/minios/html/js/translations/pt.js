window.translations = {
    "MiniOS - Fast. Simple. Reliable.": "MiniOS - Rápido. Simples. Fiável.",
    "Website": " Site",
    "News": " Notícias",
    "Community": " Comunidade",
    "Documentation": " Documentação",
    "Source code": " Código fonte",
    "Thank you for choosing MiniOS.": "Obrigado por escolher o MiniOS.",
    "We hope you enjoy our system. We try to make MiniOS beautiful, simple and convenient for you.": "Esperamos que goste do nosso sistema. Tentamos tornar o MiniOS bonito, simples e conveniente para si."
};