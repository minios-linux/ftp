window.translations = {
    "MiniOS - Fast. Simple. Reliable.": "MiniOS - Cepat. Sederhana. Andal.",
    "Website": " Situs",
    "News": " Berita",
    "Community": " Komunitas",
    "Documentation": " Dokumentasi",
    "Source code": " Kode sumber",
    "Thank you for choosing MiniOS.": "Terima kasih telah memilih MiniOS.",
    "We hope you enjoy our system. We try to make MiniOS beautiful, simple and convenient for you.": "Kami berharap Anda menikmati sistem kami. Kami berusaha membuat MiniOS indah, sederhana, dan nyaman untuk Anda."
};